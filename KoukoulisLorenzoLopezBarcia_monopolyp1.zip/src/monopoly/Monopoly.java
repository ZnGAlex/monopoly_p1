package monopoly;

import monopoly.mapa.*;

public class Monopoly {

    ////////////////////////////////////////////////////////////
    // EMPREGAR FONTE MONOSPACED, P.E. COMO CONSOLA //
    ////////////////////////////////////////////////////////////
    public static void main(String[] args) {
        new Menu();
    }
    
}
